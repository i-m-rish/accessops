import os

os.environ.setdefault("JWT_SECRET", "dev-secret-for-tests")
